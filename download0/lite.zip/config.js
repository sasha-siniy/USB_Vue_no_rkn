var CONFIG = {
    autolapse: true,
    autopoop: false,
    autoclose: true,
    autoclose_delay: 0,
    music: false,
    jb_behavior: 0
};
var payloads = [];
